package com.example.seeku_health_calc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
